<?php

// Konfigurasi koneksi ke database
$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "cash_basket";

// Membuat koneksi
$connection = new mysqli($hostname, $username, $password, $dbname);

?>