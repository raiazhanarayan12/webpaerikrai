-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 20 Feb 2024 pada 08.42
-- Versi server: 10.4.24-MariaDB
-- Versi PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cash_basket`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_akun`
--

CREATE TABLE `data_akun` (
  `id` int(11) NOT NULL,
  `username` varchar(64) NOT NULL,
  `password` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `data_akun`
--

INSERT INTO `data_akun` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_anggota`
--

CREATE TABLE `data_anggota` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `kelas` varchar(20) NOT NULL,
  `jabatan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `data_anggota`
--

INSERT INTO `data_anggota` (`id`, `nama`, `kelas`, `jabatan`) VALUES
(67, 'ucupij', 'XI ORACLE', 'anggota'),
(68, 'Nada naila', 'XI PM A', 'Sekertaris'),
(69, 'alif sofyan', 'XI AT B', 'Ketua'),
(71, 'Mochamad Rafly', 'XI ORACLE', 'anggota');

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_pembayaran`
--

CREATE TABLE `data_pembayaran` (
  `id` int(11) NOT NULL,
  `nama` varchar(64) NOT NULL,
  `week_1` varchar(5) NOT NULL,
  `week_2` varchar(5) NOT NULL,
  `week_3` varchar(5) NOT NULL,
  `week_4` varchar(5) NOT NULL,
  `month` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `data_pembayaran`
--

INSERT INTO `data_pembayaran` (`id`, `nama`, `week_1`, `week_2`, `week_3`, `week_4`, `month`) VALUES
(20, 'rai', 'Done', '', 'Done', '', 'november'),
(21, 'Nada naila', 'Done', 'Done', 'Done', '', 'november'),
(22, 'alif sofyan', 'Done', '', '', '', 'november');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jabatan`
--

CREATE TABLE `jabatan` (
  `id` int(11) NOT NULL,
  `jabatan` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `jabatan`
--

INSERT INTO `jabatan` (`id`, `jabatan`) VALUES
(1, 'Ketua'),
(2, 'Wakil Ketua'),
(3, 'Sekertaris'),
(4, 'anggota'),
(5, 'bendahara');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kelas`
--

CREATE TABLE `kelas` (
  `id` int(11) NOT NULL,
  `kelas` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `kelas`
--

INSERT INTO `kelas` (`id`, `kelas`) VALUES
(1, 'X PPLG A'),
(2, 'X PPLG B'),
(3, 'XI PPLG A'),
(4, 'XI PPLG B'),
(5, 'XII PPLG A'),
(6, 'XII PPLG B'),
(7, 'X ORACLE'),
(8, 'XI ORACLE'),
(9, 'XII ORACLE'),
(10, 'X ACP'),
(11, 'XI ACP'),
(12, 'XII ACP'),
(13, 'X TEI A'),
(14, 'XI TEI B'),
(15, 'XII TEI A'),
(16, 'XII TEI B'),
(17, 'X PM A'),
(18, 'XII TEI B'),
(19, 'X PM B'),
(20, 'XI PM A'),
(21, 'XI PM B'),
(22, 'XII PM A'),
(23, 'XII PM B'),
(24, 'X AT A'),
(25, 'X AT B'),
(26, 'X AT A'),
(27, 'X AT B'),
(28, 'X AT C'),
(29, 'XI AT A'),
(30, 'XI AT B'),
(31, 'XI AT C'),
(32, 'XII AT A'),
(33, 'XII AT B'),
(34, 'XII AT C'),
(35, 'X AT A'),
(36, 'X AT B'),
(37, 'X AT C'),
(38, 'XII AT C');

-- --------------------------------------------------------

--
-- Struktur dari tabel `month`
--

CREATE TABLE `month` (
  `id` int(11) NOT NULL,
  `month` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `month`
--

INSERT INTO `month` (`id`, `month`) VALUES
(3, 'january'),
(4, 'february'),
(5, 'march'),
(6, 'april'),
(7, 'may'),
(8, 'june'),
(9, 'july'),
(10, 'august'),
(11, 'september'),
(12, 'october'),
(13, 'november'),
(14, 'december');

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `vdetail`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `vdetail` (
);

-- --------------------------------------------------------

--
-- Struktur untuk view `vdetail`
--
DROP TABLE IF EXISTS `vdetail`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vdetail`  AS SELECT `data_pembayaran`.`id` AS `id`, `data_pembayaran`.`IDanggota` AS `IDanggota`, `data_anggota`.`nama` AS `nama`, `data_pembayaran`.`kelas` AS `kelas`, `data_pembayaran`.`mingguke` AS `mingguke`, `data_pembayaran`.`bulan` AS `bulan`, `data_pembayaran`.`tahun` AS `tahun` FROM (`data_pembayaran` left join `data_anggota` on(`data_pembayaran`.`IDanggota` = `data_anggota`.`IDanggota`))  ;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `data_akun`
--
ALTER TABLE `data_akun`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `data_anggota`
--
ALTER TABLE `data_anggota`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `data_pembayaran`
--
ALTER TABLE `data_pembayaran`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `jabatan`
--
ALTER TABLE `jabatan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `kelas`
--
ALTER TABLE `kelas`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `month`
--
ALTER TABLE `month`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `data_akun`
--
ALTER TABLE `data_akun`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `data_anggota`
--
ALTER TABLE `data_anggota`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT untuk tabel `data_pembayaran`
--
ALTER TABLE `data_pembayaran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT untuk tabel `jabatan`
--
ALTER TABLE `jabatan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `kelas`
--
ALTER TABLE `kelas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT untuk tabel `month`
--
ALTER TABLE `month`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
